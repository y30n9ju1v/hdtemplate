#include <iostream>
#include <type_traits>

template<typename T> 
void fn(T& arg)
{
	std::cout << is_array<T>::value << std::endl;
}
int main()
{
	int n = 0;
	int x[3] = {1,2,3};

	fn(n); 
	fn(x); 
	
}