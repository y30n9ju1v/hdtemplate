#include <iostream>
#include <type_traits>

template<bool, typename T1, typename T2> struct conditional
{
	using type = T1;
};

template<typename T1, typename T2> struct conditional<false, T1, T2>
{
	using type = T2;
};


int main()
{
	conditional<true,  int, double>::type v1;
	conditional<false, int, double>::type v2;


	std::cout << typeid(v1).name() << std::endl; 
	std::cout << typeid(v2).name() << std::endl; 
}












