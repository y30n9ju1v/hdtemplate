#include <iostream>
#include <type_traits>
#include <vector>
#include <iterator>
#include <concepts>

template<typename T> 
void fn(T& c)
{
	std::cout << "container" << std::endl;
}

template<typename T>
void fn(T& c)
{
	std::cout << "iterator" << std::endl;
}

template<typename T>
void fn(T& c)
{
	std::cout << "integer" << std::endl;
}

int main()
{
	int n = 10;
	std::vector<int> v = { 1,2,3 };
	
	fn(v);
	fn(v.begin());
	fn(n);
}