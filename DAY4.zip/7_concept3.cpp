#include <concepts>
#include <iostream>

// requires clauses �� syntax sugar

// �⺻ ���.
template<typename T> requires std::integral<T>
void f1(T a) 
{
	std::cout << "f1" << std::endl;
}

int main()
{
	f1(10);
	f2(10);
	f3(10); 
	f4(10);
	f5(10);
}