// 175 page

template<typename T> class tuple 
{
};

int main()
{
	tuple<int> t1;
	tuple<int,double> t2;
}