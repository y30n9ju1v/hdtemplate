#include <iostream>

class Singleton
{
public:
	static Singleton& getInstance()
	{
		static Singleton instance;
		return instance;
	}
};

int main()
{
	Cursor& c = Cursor::getInstance();
}