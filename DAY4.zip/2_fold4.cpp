// fold expression �� 4���� ����
// 
// (args + ...);		// E1 + ( E2 + ( E3 + E4))			unary right fold
// (args + ... + 0);	// E1 + ( E2 + ( E3 + (E4 + 0)))	binary right fold

// (... + args);		// (( E1 + E2 ) + E3 ) + E4			unary left fold
// (0 + ... + args);	// ((( 0 + E1 ) + E2 ) + E3) + E4	binary left fold





