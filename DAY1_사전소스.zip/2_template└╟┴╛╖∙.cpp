#include <iostream>
#include <list>

// template �� ���� - 8 page

template<typename T> T square(T a)
{
	return a * a;
}

template<typename T> class Vector
{
	T* buff;
};

int main()
{

}