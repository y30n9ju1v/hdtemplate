#include <iostream>

void cleanup() { std::cout << "cleanup" << std::endl; }

struct Finalizer
{
	void operator()() { std::cout << "Finalizer" << std::endl; }
};
//----------------------------------------
// 29 page Object Generator
class ScopedExit
{
	void(*handler)();
public:
	ScopedExit(void(*handler) f) : handler(f) {}
	~ScopedExit() { handler(); }
};


int main()
{	
	//....
	cleanup();
}