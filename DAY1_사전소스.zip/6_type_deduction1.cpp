// 42 page
#include <iostream>
#include "fname.h"

template<typename T> 
void fn(T arg)
{

}

int main()
{
	int 	n = 10;
	double 	d = 3.4;
	const int c = 10;

	fn<int>(3); 
	fn(n);		
	fn(d);		
	fn(c);		
}