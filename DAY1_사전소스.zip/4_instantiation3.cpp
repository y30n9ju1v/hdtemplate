template<typename T>
T square(T a)
{
	return a * a;
}

template<typename T>
class List
{
public:
	List(int sz, const T& value) {}
};

int main()
{
	square<int>(3);
	square(3);

	List<int> s1(10, 3);
	List      s2(10, 3);
}

