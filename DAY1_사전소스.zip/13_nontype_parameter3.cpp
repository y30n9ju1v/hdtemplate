#include <iostream>
#include <vector>

// make array
int main()
{
	int x[5] = {1,2,3,4,5};

	std::vector<int>   v = {1,2,3,4,5};
	


}