template<typename T>
class Point
{
	T x, y;
public:
	Point(const T& a, const T& b) : x(a), y(b) {}
};

int main()
{
	Point<int> p1(1, 2);  // ok
	Point<int> p2 = p1;   // ok

	Point<double> p3 = p1;// ?? 

}