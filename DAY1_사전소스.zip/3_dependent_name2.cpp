template<typename T> struct Object
{
	using type = int;

	template<typename U> 
	static void mf() {	}
};

template<typename T>
void foo()
{
//	Object<int>::type t1; 
	Object<T>::type t1; 

	Object<int>::mf<double>();
}

int main()
{
	foo<int>();
}