#include <iostream>

// template instantitaion ��� Ȯ�� �ϴ� ��� - 12 page
// 1. godbolt.org
// 2. cppinsights.io

template<typename T> 
T square(T a)
{
	return a * a;
}

int main()
{
	square<int>(3);	
	square<double>(3.3);
	square(3);
}

