#include <iostream>

// Vector vs Vector<T>

template<typename T>
class Vector
{
	T* ptr;
	std::size_t  size;
public:
	Vector(std::size_t sz) : size(sz)
	{
		ptr = new T[sz];
	}
	~Vector() { delete[] ptr; }

	T& operator[](std::size_t idx) { return ptr[idx];}

};

void fn(? v) {}

int main()
{
	Vector v(10); // error

	fn(v);
}