#include <iostream>
#include <functional>

// 27page. identity
template<typename T> void foo(T a)
{
}

template<typename T> void goo(T a)
{
}

int main()
{
	foo(10);
	goo(10);
}