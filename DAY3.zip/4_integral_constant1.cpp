#include <iostream>

template<int N> struct int2type
{
	enum { value = N };
};

int main()
{
	int2type<0> t1;
	int2type<1> t2;
}