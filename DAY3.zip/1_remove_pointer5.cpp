#include <iostream>
#include <type_traits>


template<typename T>
void fn(const T& arg)
{
}

int main()
{
	int n = 0;
	fn(&n);
}