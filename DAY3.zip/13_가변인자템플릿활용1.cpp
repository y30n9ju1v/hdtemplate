#include <iostream>

int f(int a, double b) { return 0; }

// �Լ��� ��ȯ Ÿ�� ���ϱ�


template<typename T> void foo(T& a) 
{
	typename result<T>::type n;  

	std::cout << typeid(n).name() << std::endl;  
}

int main()
{
	foo(f);
}