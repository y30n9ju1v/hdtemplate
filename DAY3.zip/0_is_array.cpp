#include <iostream>
#include <type_traits>

template<typename T> 
void fn(T& arg)
{
	std::cout << std::is_array<T>::value << std::endl;

	std::cout << std::extent<T, 0>::value << std::endl;
}

int main()
{
	int x[3][2] = { 0 };
	fn(x);
}