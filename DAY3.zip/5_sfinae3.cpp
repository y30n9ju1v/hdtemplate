#include <iostream>

void fn(...) 
{ 
	std::cout << "..." << std::endl; 
}


template<typename T> 
void fn(T a) 
{ 
	typename T::type n; 
}

int main()
{
	fn(3);
}
