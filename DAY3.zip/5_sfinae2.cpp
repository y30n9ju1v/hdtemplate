#include <iostream>

template<typename T> 
int fn(T  a) { std::cout << " T "; return 0; }

int fn(... ) { std::cout << "..."; return 0; }


int main()
{
	fn(3);
}
