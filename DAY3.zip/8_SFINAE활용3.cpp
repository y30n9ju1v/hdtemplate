#include <iostream>

class Test
{
public:
	int size() { return 10; }
};
//---------------------------------
template<typename T> void check(? ) {}
template<typename T> void check(? ) {}

int main()
{
	
}