#include <iostream>

template<typename>
inline constexpr int made_year = -1;

class AAA {};

class BBB {};

int main()
{
	std::cout << made_year<AAA> <<std::endl;
	std::cout << made_year<BBB> <<std::endl;
	std::cout << made_year<int> <<std::endl;
	
}



