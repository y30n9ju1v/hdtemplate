#include <iostream>

template<typename T> struct remove_pointer
{
	using type = T;
};

template<typename T> struct remove_pointer<T*>
{
	using type = T;
};

int main()
{
	remove_pointer<int***>::type n;

	std::cout << typeid(n).name() << std::endl;
}