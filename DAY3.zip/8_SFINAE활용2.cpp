#include <iostream>

int foo(int a, int b) { return 0; }

int main()
{
	int a = 10;

	int n1 = sizeof(a);
}