#include <iostream>

template<std::size_t N> struct Factorial
{
	enum { value = N * Factorial<N-1>::value };
};

int main()
{
	int ret = Factorial<5>::value;
	

	std::cout << ret << std::endl;
}