#include <iostream>

class Test
{
public:
	int size() { return 10; }
};
int main()
{
	bool b = has_size_function<Test>::value;
}